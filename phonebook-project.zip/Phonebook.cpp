/*This is our implementation file for our Phone Book */


#include "Phonebook.h"
#include <iostream>
#include <cstddef> //NULL is defined here

using namespace std;

/************PRIVATE FUNCTIONS*****************/

//Helper function to add entry to Phonebook
Node* Phonebook::insert(Node *root, string name, string number){
    if (root == NULL){          //Base Case. Creates New Node
        Node *node = new Node;
        node->left = NULL;
        node->right = NULL;
        node->name = name;
        node->number = number;
        root = node;
        
    }
    else if (name < root->name) //Adds to Right Subtree
        root->left = insert(root->left, name, number);
    else
        root->right = insert(root->right, name, number); //Inserts to Right Subtree
    return root;
}

//Helper function to remove an entry from Phonebook
Node* Phonebook::removeEntry(Node *&root, string name){
    if(root == NULL)
	    return root;
	    
	else if(name < root->name) //Goes to the Left Subtree
	    root->left = removeEntry(root->left,name);
	    
	else if (name > root->name) //Goes to the Right Subtree
	    root->right = removeEntry(root->right,name);
	    
	//Once Item is found	
	else {
		
		//No Child Case
		if(root->left == NULL && root->right == NULL) { 
			delete root;
			root = NULL;
		}
		
		//Right Child Case
		else if(root->left == NULL) {
			struct Node *temp = root;
			root = root->right;
			delete temp;
		}
		//Left Child Case 
		else if(root->right == NULL) {
			struct Node *temp = root;
			root = root->left;
			delete temp;
		}
		
		//Two Children Case
		else { 
			struct Node *temp = findMin(root->left);
			temp->left = root->left;
			temp->right = root->right;
			root->name = temp->name;
			root->left = temp-> left;
			root->right = temp -> right;
			destroy(temp);
		}
	}
	return root;
}

//Helper function for Delete. Finds the Right Most Node in Left Subtree
Node* Phonebook::findMin(Node *root){
    while(root->right != NULL) 
	    root = root->right;
	return root;
}

//Helper Function for Search & Add. A Precheck before Program Seach or Adds
bool Phonebook::isItThere(Node *root, string name){
   bool found;
   upper(name);
   while (root != NULL){
    if (name == root->name){
        found = true;
        break;
    }
    else if (name < root->name){ //Checks Left Subtree
       found = isItThere(root->left,name);
       break;
    }
    else if (name > root->name){ //Checks Right Subtree
       found = isItThere(root->right,name);
       break;
    }
    else {
       found = false;
       break;
    }
   }
   return found;
}

//Helper Function for Search. Prints the Entry's name and number
void Phonebook::showNumber(Node *root, string name){
    upper(name);
    if (name == root->name){
        cout << endl << name << "'s number: " << root->number;
   }
   else if (name < root->name){ //Left Subtree
       showNumber(root->left, name);
   }
   else if (name > root->name){ //Right Subtree
       showNumber(root->right, name);
   }
   else {
       return;
   }
   
}

//Helper Function for Delete. Deletes the Node that replaces the Node that is deleted
void Phonebook::destroy(Node *node){
    if(node!=NULL){
        destroy(node->left); 
        destroy(node->right);
        delete node;
    }
}

//Helper Finction for Print. In-Order Traversal Method
void Phonebook::printTree(Node *root){
    if (root != NULL)
    {
        printTree(root->left); //Prints Left Subtree
        cout << root->name << " - " << root->number << endl;; //Prints Root
        printTree(root->right); //Print Right Subtree
    }
    
}

//Helper Function for Reverse reverseLookup
void Phonebook::findNumber(Node *root, string number, string &name){
    string nameFound = name;
    if(root!= NULL){
        if (number == root->number){ //Checks Root
        nameFound = root->name;
        }
        else{
        if(nameFound == "N/A") //Checks Items in Left Subtree
            findNumber(root->left, number, nameFound);
        if (nameFound == "N/A")//Checks Items in Right Subtree
            findNumber(root->right, number, nameFound);
        
    }
    name = nameFound;
    }
}

//Upper Case a String. Used to Ensure all entries are all in the same case 
void Phonebook::upper(string &name){
    for(int i=0; i<name.length(); i++){
        name[i]=toupper(name[i]);
    }
}

/***************PUBLIC FUNCTIONS***************/

//Default Constructor
Phonebook::Phonebook(){
    root = NULL; //Sets root to NULL 
}

//Add Entry to Phonebook
void Phonebook::add(string name, string number){
    upper(name);
    if (!isItThere(root, name)){ //Checks to see if Entry Exists
        if (root != NULL){
            insert(root,name, number); //Adds to Existing Tree
        } 
         else 
            root = insert(root, name, number);
    }
    else
        cout << "\nEntry with that name is already in Phonebook!\n";
}

//Remove Entry from Phonebook
void Phonebook::remove(string name){
    upper(name);
    removeEntry(root, name);
}

//Search Entry from Phonebook by a given name
void Phonebook::search(string name){
   if (isItThere(root, name) == true){
       cout << "\n";
       showNumber(root, name);
   }
   else
    cout << "\nEntry is not in Phonebook!";
}

//Search Entry from Phonebook by a given Number
void Phonebook::reverseLookup(string number){
    string nameFound = "N/A";
    
    findNumber(root, number, nameFound);
    

    search(nameFound);
};

//Display Phonebook
void Phonebook::print(){
    printTree(root);
} 


