//Program for Phonebook using BSTs


#include "Phonebook.h"
#include <iostream>

using namespace std;

int main(){
    Phonebook book1; //Phonebook Object 
    char choice; //Holds the User's Choice
    string name; 
    string number;
    
    do {
        //Main Menu for Program
        cout << "\nWelcome to Phone Book Version 1! Please Choose an Option\n";
        cout << "A – Add a new contact to the phone book.\n";
        cout << "D – Delete a contact from the phone book.\n";
        cout << "F – Find the phone number of a contact by name.\n";
        cout << "R – Find the name of the contact based on their phone number\n";
        cout << "P – Display all the contacts in the phone book.\n";
        cout << "Q – Quit the application.\n";
        
        cin >> choice;
        cout << endl;
        choice = toupper(choice);
        
        switch(choice) {
            //Adds A New Contact
            case 'A':{
                cout << "\nAdding a New Contact...";
                cout << "\nPlease Enter Their First Name: ";
                cin >> name;
                cout << "Please Enter Number: ";
                cin >> number;
                book1.add(name, number);
                break;}
            //Deletes a Contact
            case 'D':{
                cout << "\n Deleting A Contact...\n";
                cout << "Enter A Contact to Delete: \n";
                cin >> name;
                book1.remove(name);
                break;}
            //Searches By Name
            case 'F':{
                cout << "\n Searching For A Contact....\n";
                cout << "Enter Their First Name: \n";
                cin >> name;
                book1.search(name);
                break;
            }
            //Searches By Phone Number
            case 'R':{
                cout << "\nReverse Lookup....\n";
                cout << "Please Enter the Number.\n";
                cin >> number;
                book1.reverseLookup(number);
            }
                
                break;
            //Displays the Contacts
            case 'P':
                book1.print();
                break;
        }
    }
    while(choice!= 'Q');
}
