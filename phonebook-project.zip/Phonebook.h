//Header file for the Phonebook

#include <string>

using namespace std;

//Defines a simple Node for the BST

struct Node {
    string name; //Holds the person's name
    string number; //Holds the person's number
    Node *left; //Points to the left child
    Node *right; //Point to the right child
};

//Specification for Phonebook Class 

class Phonebook {
    private:
        Node* root; //Points to the root of the tree
        
        //Adds Entry to Phonebook
        Node* insert(Node *root, string name, string number);
        
        //Removes Entry From Phonebook
        Node* removeEntry(Node *&root, string key);
        
        //Finds the right most Node in Left Subtree
        Node* findMin(Node *root);
        
        //A Precheck before Entry is added or Searched for
        bool isItThere(Node *root, string name);
        
        //Prints an Entry Name and Number
        void showNumber(Node *root, string name);
        
        //Deletes Node when it replaces another in BST
        void destroy(Node *node);
        
        //Prints Entries in Alphabetical Order 
        void printTree(Node *root);
        
        //Upper Case a String
        void upper(string &name);
        
        //Finds Number in Phonebook
        void findNumber(Node *root, string number, string &name);
        
        
        
    public:
        //Default Constructor
        Phonebook();
        
        //Add Entry to Phonebook
        void add(string name, string phoneNumber);
        
        //Remove Entry from Phonebook
        void remove(string name);
        
        //Search Entry from Phonebook by a given name
        void search(string name);
        
        //Search Entry from Phonebook by a given Number
        void reverseLookup(string phoneNumber);
        
        //Display Phonebook
        void print();
    
};